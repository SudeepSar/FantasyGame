import sqlite3
Myplayer=sqlite3.connect('final.db')
cursplay=Myplayer.cursor()
def batsmen():
    role='BAT'
    sql="SELECT Player FROM stats WHERE ctg='"+role+"'";
    listBat = [] # Added new list
    cursplay.execute(sql)
    while True:
        record=cursplay.fetchone()
        if record==None:
            break
        rsl=record[0]
        print(rsl)
        listBat.append(rsl) # stored all te batsman (same for others)
    return listBat # returned the list

def bowlers():
    role='BWL'
    sql="SELECT Player FROM stats WHERE ctg='"+role+"'";
    listBowl = []
    cursplay.execute(sql)
    while True:
        record=cursplay.fetchone()
        if record==None:
            break
        rsl=record[0]
        print(rsl)
        listBowl.append(rsl)
    return listBowl

def allrounders():
    role='AR'
    sql="SELECT Player FROM stats WHERE ctg='"+role+"'";
    listAr = []
    cursplay.execute(sql)
    while True:
        record=cursplay.fetchone()
        if record==None:
            break
        rsl=record[0]
        print(rsl)
        listAr.append(rsl)
    return listAr

def wicketkeepers():
    role='WK'
    sql="SELECT Player FROM stats WHERE ctg='"+role+"'";
    listWk = []
    cursplay.execute(sql)
    while True:
        record=cursplay.fetchone()
        if record==None:
            break
        rsl=record[0]
        print(rsl)
        listWk.append(rsl)
    return listWk
    
    
